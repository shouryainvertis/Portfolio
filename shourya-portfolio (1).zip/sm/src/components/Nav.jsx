import {useState} from 'react';import {Menu,X} from 'lucide-react';
const items=[['Doors','#doors'],['About','#about'],['Journey','#journey'],['Work','#work'],['Skills','#skills'],['Hire me','#hire']];
export default function Nav(){const [o,s]=useState(false);
 return <header className="fixed top-0 inset-x-0 z-50 flex justify-between items-center px-5 py-4 mix-blend-difference text-white">
  <a href="#top" className="font-display text-lg">SM.</a>
  <nav className="hidden md:flex gap-8 text-sm">{items.map(([n,h])=><a key={h} href={h}>{n}</a>)}</nav>
  <button className="md:hidden" aria-label="Menu" onClick={()=>s(!o)}>{o?<X/>:<Menu/>}</button>
  {o&&<div className="md:hidden fixed inset-0 bg-ink flex flex-col justify-center items-center gap-6 text-3xl font-display">{items.map(([n,h])=><a key={h} href={h} onClick={()=>s(false)}>{n}</a>)}</div>}</header>}

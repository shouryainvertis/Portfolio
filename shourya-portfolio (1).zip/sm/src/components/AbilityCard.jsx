import {useRef,useState} from 'react';import {site} from '../config/site';
export default function AbilityCard(){const c=useRef(null),[f,setF]=useState(false),[d,setD]=useState(false);
 const move=(e)=>{const b=c.current.getBoundingClientRect(),x=(e.clientX-b.left)/b.width-.5,y=(e.clientY-b.top)/b.height-.5;
  c.current.style.setProperty('--rx',`${-y*22}deg`);c.current.style.setProperty('--ry',`${x*22}deg`);c.current.style.setProperty('--gx',`${(x+.5)*100}%`);c.current.style.setProperty('--gy',`${(y+.5)*100}%`)};
 const reset=()=>{['--rx','--ry'].forEach(k=>c.current.style.setProperty(k,'0deg'))};
 const face="absolute inset-0 rounded-3xl p-6 bf-hide flex flex-col justify-between overflow-hidden";
 return <section className="py-20 px-5 grid place-items-center"><p className="mb-6 text-sm opacity-60">My ability card · drag, tilt, tap to flip</p>
  <div className="persp touch-none" onPointerMove={move} onPointerLeave={reset}>
   <div ref={c} role="button" tabIndex={0} aria-label="Flip ability card" onClick={()=>!d&&setF(!f)} onKeyDown={e=>e.key==='Enter'&&setF(!f)}
    onPointerDown={()=>setD(false)} className="relative w-[280px] h-[400px] p3d transition-transform duration-300 cursor-grab"
    style={{transform:`rotateX(var(--rx,0deg)) rotateY(calc(var(--ry,0deg) + ${f?180:0}deg))`,filter:'drop-shadow(0 30px 30px rgba(0,0,0,.3))'}}>
    <div className={face+' bg-ink text-paper'}><span className="text-xs opacity-60">DEVELOPER ID</span>
     <div><h3 className="font-display text-3xl">Shourya Maheshwari</h3><p className="text-volt mt-1">Creative Developer</p></div><span className="text-xs opacity-50">Invertis University · CSE</span>
     <span className="pointer-events-none absolute inset-0" style={{background:'radial-gradient(circle at var(--gx,50%) var(--gy,30%),rgba(255,255,255,.22),transparent 55%)'}}/></div>
    <div className={face+' bg-volt text-white'} style={{transform:'rotateY(180deg)'}}><div><p className="text-xs opacity-70">SKILLS</p><p className="mt-2 text-sm leading-relaxed">{Object.values(site.skills).flat().join(' · ')}</p></div>
     <div className="text-sm space-y-1"><a href={site.links.leetcode} target="_blank" rel="noreferrer" onClick={e=>e.stopPropagation()} className="underline block">LeetCode profile</a>
      <a href={site.links.linkedin} target="_blank" rel="noreferrer" onClick={e=>e.stopPropagation()} className="underline block">LinkedIn</a></div>
     <p className="text-xs opacity-80">CSE student building real-world web apps.</p></div></div></div></section>}

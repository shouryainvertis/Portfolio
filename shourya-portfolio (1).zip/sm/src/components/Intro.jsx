import {useEffect,useRef} from 'react';import gsap from 'gsap';import {site} from '../config/site';
export default function Intro({onDone}){const r=useRef(null);
 useEffect(()=>{const tl=gsap.timeline({onComplete:onDone});
  tl.from('.ch',{yPercent:110,stagger:.04,duration:.8,ease:'power4.out'}).to('.bar',{scaleX:1,duration:1,ease:'power2.inOut'},0)
   .to('.ch',{yPercent:-110,stagger:.02,duration:.5,delay:.3,ease:'power3.in'}).to(r.current,{yPercent:-100,duration:.9,ease:'power4.inOut'});
  r.current._tl=tl;return()=>tl.kill()},[onDone]);
 return <div ref={r} className="fixed inset-0 z-[100] bg-ink text-paper grid place-items-center">
  <button onClick={()=>{r.current._tl.progress(1)}} className="absolute top-5 right-5 text-sm underline">Skip intro</button>
  <h1 className="font-display text-4xl md:text-7xl overflow-hidden flex flex-wrap justify-center px-4" aria-label={site.name}>
   {site.name.split('').map((c,i)=><span key={i} className="ch inline-block">{c===' '?'\u00A0':c}</span>)}</h1>
  <div className="bar absolute bottom-16 left-8 right-8 h-px bg-volt origin-left scale-x-0"/></div>}

import {useState} from 'react';import {AnimatePresence,motion} from 'framer-motion';import {site} from '../config/site';
const types=['Website','Web Application','Portfolio','UI/UX Design','Other'],budgets=['Under ₹10k','₹10k–50k','₹50k+','Not sure yet'],starts=['ASAP','Within a month','Flexible'];
const Opts=({v,list,set})=><div className="grid gap-3">{list.map(o=><button type="button" key={o} onClick={()=>set(o)} aria-pressed={v===o} className={`text-left px-5 py-3 rounded-2xl border ${v===o?'bg-volt text-white border-volt':'border-paper/30'}`}>{o}</button>)}</div>;
export default function HireForm(){const [s,setS]=useState(0),[d,setD]=useState({type:'',budget:'',start:'',about:'',name:'',email:'',message:''}),[err,setErr]=useState(''),[done,setDone]=useState(false),[busy,setBusy]=useState(false);
 const set=k=>v=>{setD(x=>({...x,[k]:v}));setErr('')};const inp=k=>e=>set(k)(e.target.value);
 const valid=()=>[d.type,d.budget,d.start,d.about.trim().length>9,d.name.trim()&&/^\S+@\S+\.\S+$/.test(d.email)&&d.message.trim()][s];
 const next=()=>{if(!valid()){setErr(['Pick what you want to build.','Pick a budget.','Pick a start time.','Tell me a little more (10+ characters).','Enter your name, a valid email and a message.'][s]);return}s<4?setS(s+1):submit()};
 const submit=async()=>{setBusy(true);const ep=import.meta.env.VITE_FORMSPREE_ENDPOINT;
  try{if(ep){const r=await fetch(ep,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(d)});if(!r.ok)throw 0}
   else{location.href=`mailto:${site.email}?subject=${encodeURIComponent('Project: '+d.type)}&body=${encodeURIComponent(Object.entries(d).map(([k,v])=>k+': '+v).join('\n'))}`}
   setDone(true)}catch{setErr('Could not send. Please email me directly.')}setBusy(false)};
 const field="w-full bg-transparent border-b border-paper/40 py-3 mb-4 outline-none focus:border-volt";
 const steps=[<Opts v={d.type} list={types} set={set('type')}/>,<Opts v={d.budget} list={budgets} set={set('budget')}/>,<Opts v={d.start} list={starts} set={set('start')}/>,
  <textarea className={field} rows={5} placeholder="Describe your project" value={d.about} onChange={inp('about')}/>,
  <div><input className={field} placeholder="Name" value={d.name} onChange={inp('name')}/><input className={field} type="email" placeholder="Email" value={d.email} onChange={inp('email')}/><textarea className={field} rows={3} placeholder="Message" value={d.message} onChange={inp('message')}/></div>];
 const q=['What do you want to build?','What is your budget?','When do you want to start?','Tell me about your project.','Contact details.'];
 return <section id="hire" className="py-20 px-5 bg-ink text-paper"><div className="max-w-xl mx-auto">
  <h2 className="font-display text-4xl md:text-5xl mb-8">Have Something in Mind? Let's Build It.</h2>
  {done?<p role="status" className="text-xl">Thank you{d.name?`, ${d.name}`:''}! Your message is on its way. I'll reply soon.</p>:<>
   <div className="h-1 bg-paper/20 rounded mb-6"><div className="h-full bg-volt rounded transition-all" style={{width:`${(s+1)*20}%`}}/></div>
   <p className="text-xs opacity-60 mb-2">Step {s+1} of 5</p><h3 className="text-2xl mb-5">{q[s]}</h3>
   <AnimatePresence mode="wait"><motion.div key={s} initial={{opacity:0,x:30}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-30}} transition={{duration:.25}}>{steps[s]}</motion.div></AnimatePresence>
   {err&&<p role="alert" className="text-orange-400 mt-2 text-sm">{err}</p>}
   <div className="mt-6 flex justify-between"><button type="button" disabled={!s} onClick={()=>setS(s-1)} className="px-5 py-2 rounded-full border border-paper/30 disabled:opacity-30">Back</button>
    <button type="button" disabled={busy} onClick={next} className="px-6 py-2 rounded-full bg-volt">{s===4?(busy?'Sending…':'Send'):'Next'}</button></div></>}</div></section>}

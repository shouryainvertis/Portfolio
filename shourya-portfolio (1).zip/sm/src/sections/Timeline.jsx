import {useReveal} from '../animations/reveal';import {site} from '../config/site';
export default function Timeline(){const r=useReveal();return <section id="journey" ref={r} className="py-20 px-5 max-w-3xl mx-auto">
 <h2 data-r className="font-display text-4xl md:text-6xl mb-12">Let's go back in time.</h2>
 <ol className="relative border-l-2 border-ink/20 ml-2 space-y-10">{site.timeline.map((t,i)=><li data-r key={i} className="pl-8 relative">
  <span className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-volt ring-4 ring-paper"/>
  <p className="text-sm text-volt font-semibold">{t.when}</p><h3 className="font-display text-2xl">{t.title}</h3><p className="text-sm opacity-60">{t.where}</p><p className="mt-2">{t.text}</p></li>)}</ol></section>}

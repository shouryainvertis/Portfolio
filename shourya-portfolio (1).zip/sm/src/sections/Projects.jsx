import {ArrowUpRight} from 'lucide-react';import {useReveal} from '../animations/reveal';import {site} from '../config/site';
const Btn=({href,children})=>href?<a href={href} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-full border border-paper/40 text-sm inline-flex gap-1 items-center">{children}<ArrowUpRight size={14}/></a>:<span className="px-4 py-2 rounded-full border border-paper/15 text-sm opacity-40">{children}: coming soon</span>;
export default function Projects(){const r=useReveal();return <section id="work" ref={r} className="py-20 px-5 bg-ink text-paper">
 <div className="max-w-6xl mx-auto"><h2 data-r className="font-display text-4xl md:text-6xl mb-12">Things I've Built.</h2>
 <div className="space-y-8">{site.projects.map((p,i)=><article data-r key={p.title} className="group grid md:grid-cols-2 gap-6 border-t border-paper/20 pt-8">
  <div className="aspect-video rounded-2xl overflow-hidden grid place-items-center font-display text-5xl md:text-6xl transition-transform duration-500 group-hover:scale-[.97]" style={{background:site.doors[i%5].tone}}>{p.title}</div>
  <div className="flex flex-col justify-between"><div><h3 className="font-display text-3xl">{p.title}</h3><p className="mt-2 opacity-80">{p.desc}</p>
   <p className="mt-4 flex flex-wrap gap-2">{p.stack.map(s=><span key={s} className="text-xs px-3 py-1 rounded-full bg-paper/10">{s}</span>)}</p></div>
   <div className="mt-6 flex flex-wrap gap-3"><Btn href={p.live}>Live</Btn><Btn href={p.repo}>GitHub</Btn></div></div></article>)}</div></div></section>}

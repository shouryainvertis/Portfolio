import {useReveal} from '../animations/reveal';import {site} from '../config/site';
export default function Skills(){const r=useReveal();return <section id="skills" ref={r} className="py-20 px-5 max-w-5xl mx-auto">
 <h2 data-r className="font-display text-4xl md:text-6xl mb-10">Skills</h2>
 <div className="grid sm:grid-cols-2 gap-6">{Object.entries(site.skills).map(([k,v])=><div data-r key={k} className="p-6 rounded-3xl border border-ink/15"><h3 className="font-display text-xl mb-3">{k}</h3>
  <div className="flex flex-wrap gap-2">{v.map(s=><span key={s} className="px-3 py-1.5 rounded-full bg-ink text-paper text-sm hover:bg-volt transition-colors">{s}</span>)}</div></div>)}</div></section>}

import {site} from '../config/site';
export default function Footer(){const L=[['Email',`mailto:${site.email}`],['LinkedIn',site.links.linkedin],['GitHub',site.links.github],['Instagram',site.links.instagram],['LeetCode',site.links.leetcode]].filter(l=>l[1]);
 return <footer className="py-20 px-5 bg-paper"><h2 className="font-display text-4xl md:text-7xl max-w-4xl">Let's Create Something Amazing.</h2>
  <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-lg">{L.map(([n,h])=><a key={n} href={h} target={n==='Email'?undefined:'_blank'} rel="noreferrer" className="underline hover:text-volt">{n}</a>)}</div>
  <p className="mt-16 font-display text-xl">Shourya Maheshwari</p><p className="text-sm opacity-60">Designed & Developed with Creativity.</p></footer>}

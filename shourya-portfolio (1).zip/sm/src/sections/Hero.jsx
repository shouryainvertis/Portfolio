import {useEffect,useState} from 'react';import {ArrowDown} from 'lucide-react';import {site} from '../config/site';
export default function Hero(){const [i,setI]=useState(0);useEffect(()=>{const t=setInterval(()=>setI(x=>(x+1)%site.roles.length),2000);return()=>clearInterval(t)},[]);
 return <section id="top" className="min-h-screen px-5 pt-28 pb-10 grid md:grid-cols-2 gap-8 items-center max-w-7xl mx-auto">
  <div><p className="inline-flex items-center gap-2 text-sm mb-6"><span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"/>Available for work</p>
   <h1 className="font-display text-5xl md:text-8xl leading-[1.02]">Hello, I'm <em className="text-volt">Shourya.</em></h1>
   <p className="mt-6 text-lg md:text-xl max-w-md">Building digital experiences through code and creativity.</p>
   <p className="mt-3 h-7 font-semibold text-volt" aria-live="polite">{site.roles[i]}</p>
   <p className="mt-4 max-w-md opacity-70">CSE student at Invertis University, Bareilly, crafting responsive interfaces and MERN apps.</p>
   <div className="mt-8 flex flex-wrap gap-3"><a href="#hire" className="px-6 py-3 bg-ink text-paper rounded-full">Hire Me</a><a href="#work" className="px-6 py-3 border border-ink rounded-full">Explore My Work</a></div></div>
  <div className="relative aspect-[4/5] max-w-sm mx-auto w-full rounded-[2rem] overflow-hidden bg-ink/10 grid place-items-center">
   <img src={site.photo} alt="Shourya Maheshwari" className="absolute inset-0 w-full h-full object-cover" onError={e=>e.currentTarget.style.display='none'}/>
   <span className="opacity-40 text-sm px-4 text-center">Add your photo at public/photo.jpg</span></div>
  <a href="#doors" className="md:col-span-2 flex items-center gap-2 text-sm" aria-label="Scroll down">Scroll <ArrowDown size={16} className="animate-bounce"/></a></section>}

import {useReveal} from '../animations/reveal';import {site} from '../config/site';
export default function About(){const r=useReveal();return <section id="about" ref={r} className="py-20 px-5 max-w-5xl mx-auto">
 <h2 data-r className="font-display text-4xl md:text-6xl">Behind Every Line of Code.</h2>
 <div className="mt-10 space-y-6 text-lg md:text-2xl leading-snug">{site.about.map((p,i)=><p data-r key={i}>{p}</p>)}</div></section>}

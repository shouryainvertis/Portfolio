import {useEffect,useState} from 'react';import {Github,Code2} from 'lucide-react';import {site} from '../config/site';
export default function Profiles(){const [repos,setR]=useState([]);
 useEffect(()=>{if(!site.githubUser)return;fetch(`https://api.github.com/users/${site.githubUser}/repos?sort=updated&per_page=4`).then(r=>r.ok?r.json():[]).then(setR).catch(()=>{})},[]);
 return <section className="py-20 px-5 max-w-5xl mx-auto grid md:grid-cols-2 gap-6">
  <div className="p-6 rounded-3xl bg-ink text-paper"><Github/><h3 className="font-display text-2xl mt-3">GitHub</h3>
   {repos.length?<ul className="mt-3 space-y-1 text-sm">{repos.map(r=><li key={r.id}><a className="underline" href={r.html_url} target="_blank" rel="noreferrer">{r.name}</a></li>)}</ul>:<p className="mt-3 text-sm opacity-60">Add your username in src/config/site.js to list repositories live.</p>}
   {site.links.github&&<a className="inline-block mt-4 underline" href={site.links.github} target="_blank" rel="noreferrer">Open profile</a>}</div>
  <a href={site.links.leetcode} target="_blank" rel="noreferrer" className="p-6 rounded-3xl bg-volt text-white block hover:-translate-y-1 transition-transform"><Code2/><h3 className="font-display text-2xl mt-3">LeetCode</h3><p className="mt-3 text-sm">Problem-solving practice. Open profile →</p></a></section>}

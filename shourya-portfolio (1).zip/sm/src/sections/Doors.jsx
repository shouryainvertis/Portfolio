import {useRef,useState} from 'react';import gsap from 'gsap';import {site} from '../config/site';
export default function Doors(){const [open,setOpen]=useState(null);const refs=useRef([]);
 const toggle=(i)=>{const prev=open;
  if(prev!==null)gsap.to(refs.current[prev],{rotateY:0,duration:.8,ease:'power3.inOut'});
  if(prev===i){setOpen(null);return}
  gsap.to(refs.current[i],{rotateY:-105,duration:1.1,ease:'power3.out'});setOpen(i)};
 const tilt=(e,i)=>{if(open===i||e.pointerType==='touch')return;gsap.to(refs.current[i],{rotateY:-14,duration:.4})};
 const rest=(i)=>{if(open!==i)gsap.to(refs.current[i],{rotateY:0,duration:.5})};
 return <section id="doors" className="py-20 bg-ink text-paper">
  <h2 className="font-display text-4xl md:text-6xl px-5 max-w-4xl mx-auto">Every Door Opens a New Possibility.</h2>
  <p className="px-5 max-w-4xl mx-auto mt-3 opacity-60 text-sm">Tap or click a door. Swipe along the wall on mobile.</p>
  <div className="mt-12 flex gap-5 overflow-x-auto snap-x snap-mandatory px-5 pb-6 md:justify-center">
   {site.doors.map((d,i)=><div key={d.id} className="snap-center shrink-0 w-[68vw] max-w-[230px] h-[380px] persp">
    <div className="relative w-full h-full rounded-t-[7rem] overflow-hidden" style={{background:'#050506'}}>
     <div className="absolute inset-0 p-5 pt-24 text-sm leading-relaxed" style={{background:d.tone+'22'}}><p className="opacity-90">{d.text}</p></div>
     <button ref={el=>refs.current[i]=el} onClick={()=>toggle(i)} onPointerEnter={e=>tilt(e,i)} onPointerLeave={()=>rest(i)} aria-expanded={open===i} aria-label={`Open ${d.title}`}
      className="absolute inset-0 origin-left rounded-t-[7rem] text-left p-5 flex flex-col justify-end shadow-2xl" style={{background:`linear-gradient(135deg,${d.tone},#0c0c10)`,transformStyle:'preserve-3d'}}>
      <span className="absolute right-4 top-1/2 w-3 h-3 rounded-full bg-paper/80"/>
      <span className="text-xs opacity-60">0{i+1}</span><span className="font-display text-2xl">{d.title}</span></button></div></div>)}</div></section>}

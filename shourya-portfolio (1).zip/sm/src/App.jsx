import {useState,useCallback,lazy,Suspense} from 'react';import useLenis from './animations/useLenis';
import Intro from './components/Intro';import Nav from './components/Nav';import Hero from './sections/Hero';import Doors from './sections/Doors';
import AbilityCard from './components/AbilityCard';import About from './sections/About';import Timeline from './sections/Timeline';
const Projects=lazy(()=>import('./sections/Projects')),Skills=lazy(()=>import('./sections/Skills')),Profiles=lazy(()=>import('./sections/Profiles')),HireForm=lazy(()=>import('./sections/HireForm')),Footer=lazy(()=>import('./sections/Footer'));
export default function App(){const [intro,setIntro]=useState(true);useLenis();const done=useCallback(()=>setIntro(false),[]);
 return <>{intro&&<Intro onDone={done}/>}<Nav/><main><Hero/><Doors/><AbilityCard/><About/><Timeline/>
  <Suspense fallback={null}><Projects/><Skills/><Profiles/><HireForm/></Suspense></main><Suspense fallback={null}><Footer/></Suspense></>}

import {useEffect,useRef} from 'react';import gsap from 'gsap';import {ScrollTrigger} from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
export function useReveal(){const ref=useRef(null);useEffect(()=>{
 const ctx=gsap.context(()=>{gsap.from('[data-r]',{y:50,opacity:0,duration:.9,stagger:.12,ease:'power3.out',scrollTrigger:{trigger:ref.current,start:'top 80%'}})},ref);
 return()=>ctx.revert()},[]);return ref}

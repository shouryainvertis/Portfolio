// EDIT THIS FILE: all content lives here. Replace TODO placeholders with real info.
export const site={
 name:"Shourya Maheshwari",email:"shouryamaheshwari14@gmail.com",
 photo:"/photo.jpg", // TODO: put your photo at public/photo.jpg
 links:{
  linkedin:"https://www.linkedin.com/in/shourya-maheshwari-4471b742b/",
  leetcode:"https://leetcode.com/u/YrOreWuRUp/",
  github:"", // TODO: your GitHub profile URL
  instagram:"" // TODO: your Instagram URL
 },
 githubUser:"", // TODO: GitHub username enables the live repo list
 roles:["Frontend Developer","MERN Stack Developer","Creative Developer","CSE Student"],
 doors:[
  {id:"web",title:"Web Development",tone:"#2B4BFF",text:"HTML, CSS, JavaScript and React interfaces, plus Node.js, Express and MongoDB on the back end."},
  {id:"app",title:"App Development",tone:"#17181B",text:"Mobile-first responsive apps that feel native on a phone. TODO: add native app work if any."},
  {id:"ux",title:"UI/UX Design",tone:"#7A6CFF",text:"Layout, typography and interaction design, usability first. TODO: add design tools you use."},
  {id:"projects",title:"My Projects",tone:"#E9572F",text:"ATTENDX, TRIPORA and AROGYACASE. Scroll to Things I've Built."},
  {id:"journey",title:"My Journey",tone:"#1E9E7A",text:"B.Tech CSE at Invertis University, learning and building every day."}],
 about:["I'm a Computer Science & Engineering student at Invertis University in Bareilly, Uttar Pradesh.","I enjoy turning ideas into working web products, from responsive React interfaces to MERN stack applications.","I learn by building: picking up new technologies, solving problems creatively and shipping real-world apps."],
 timeline:[
  {when:"Present",title:"B.Tech, Computer Science & Engineering",where:"Invertis University, Bareilly",text:"Building a strong base in programming and computer science."},
  {when:"Ongoing",title:"Web development journey",where:"Self-learning and projects",text:"HTML, CSS, JavaScript, React, Node.js, Express, MongoDB and MySQL."},
  {when:"Ongoing",title:"Problem solving",where:"LeetCode",text:"Practising data structures and algorithms."},
  {when:"TODO",title:"Add a certification or achievement",where:"Your organisation",text:"Edit src/config/site.js and add only real entries."}],
 projects:[
  {title:"ATTENDX",desc:"Attendance tracker, currently run locally.",stack:["React","Node.js","MongoDB"],live:"",repo:""},
  {title:"TRIPORA",desc:"Trip-planning frontend prototype.",stack:["React","Tailwind CSS"],live:"",repo:""},
  {title:"AROGYACASE",desc:"Patient case-taking concept, in the planning stage.",stack:["Concept","UI/UX"],live:"",repo:""}],
 skills:{Frontend:["HTML","CSS","JavaScript","React"],Backend:["Node.js","Express.js"],Database:["MongoDB","MySQL"],Tools:["Git","GitHub","VS Code"],Additional:["Responsive Design","UI/UX","Problem Solving"]}
};

# Shourya Maheshwari Portfolio
Edit all content in `src/config/site.js` (look for TODO). Put your photo at `public/photo.jpg`.
Run: `npm install` then `npm run dev`. Build: `npm run build` (output in `dist`).
Form: create a free form at formspree.io, copy `.env.example` to `.env`, set VITE_FORMSPREE_ENDPOINT. Without it, the form opens the visitor's email app.
Netlify: push to GitHub, then Add new site > Import from Git. Build command `npm run build`, publish `dist` (already in netlify.toml). Add VITE_FORMSPREE_ENDPOINT under Site settings > Environment variables.
